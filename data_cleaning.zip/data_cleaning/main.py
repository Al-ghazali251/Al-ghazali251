import pywhatkit, time

# Send a WhatsApp Message to a Contact at 1:30 PM
# contacts = ["+2348152076180", "+2348053258472", " +2349037707669"]



numbers = []
cleaned = []
phone_contacts = []
file1 = open("phone_contacts", "r")
contacts = file1.read()

contacts = contacts.replace("\n", ",")

# print(contacts)
b = ""

for number in contacts:
    b = b + number
    if number == ",":
        numbers.append(b)
        b = ""
        continue

# print(numbers)

for n in numbers:
    f = n.rsplit(".")[0]
    cleaned.append(f)

for c in cleaned:
    add = "+234" + c
    phone_contacts.append(add)


for i in phone_contacts:
    time.sleep(10)
    pywhatkit.sendwhatmsg_instantly(i, "Hi, this is an automated whatsapp message")

print(phone_contacts)
